
# Archivo corregido y consolidado de simulación y análisis con regresión logística

set.seed(123)
n <- 500

# Variables numéricas
age <- round(rnorm(n, mean = 54, sd = 9)) # Edad
sex <- rbinom(n, 1, 0.7)                  # Sexo: 0 = mujer, 1 = hombre
rest_bp <- round(rnorm(n, mean = 130, sd = 15)) # Presión arterial en reposo
chol <- round(rnorm(n, mean = 245, sd = 50))    # Colesterol
fbs <- rbinom(n, 1, 0.15)                # Glucosa en ayunas
restecg <- sample(0:2, n, replace = TRUE, prob = c(0.5, 0.4, 0.1)) # Electrocardiograma
max_hr <- round(rnorm(n, mean = 150, sd = 22))  # Frecuencia cardíaca máxima
exang <- rbinom(n, 1, 0.3)                      # Angina inducida por ejercicio
oldpeak <- round(runif(n, min = 0.0, max = 6.2), 1) # Depresión ST
slope <- sample(1:3, n, replace = TRUE, prob = c(0.45, 0.4, 0.15)) # Pendiente ST
ca <- sample(0:4, n, replace = TRUE, prob = c(0.6, 0.2, 0.1, 0.07, 0.03)) # Vasos coloreados
chest_pain <- sample(c("typical", "asymptomatic", "nonanginal", "nontypical"),
                     n, replace = TRUE, prob = c(0.25, 0.35, 0.25, 0.15)) # Dolor torácico
thal <- sample(c("normal", "fixed", "reversable"),
               n, replace = TRUE, prob = c(0.6, 0.2, 0.2)) # Resultado del test de talio

# Modelo logit para simular AHD
logit_p <- -6 + 0.06*age + 0.02*chol + 0.03*rest_bp + 0.5*sex - 0.02*max_hr +
  0.4*fbs + 0.3*exang + 0.7*ca + 0.3*(slope == 2) - 0.5*(thal == "normal")
p_hd <- 1 / (1 + exp(-logit_p))
ahd <- factor(rbinom(n, 1, prob = p_hd), levels = c(0,1), labels = c("No", "Yes"))

# DataFrame completo
heart_df <- data.frame(
  Age = age, Sex = sex, ChestPain = chest_pain,
  RestBP = rest_bp, Chol = chol, Fbs = fbs,
  RestECG = restecg, MaxHR = max_hr, ExAng = exang,
  Oldpeak = oldpeak, Slope = slope, Ca = ca, Thal = thal, AHD = ahd
)

head(heart_df)

# Análisis exploratorio y modelos
library(ggplot2); library(dplyr); library(minpack.lm)

# Modelos logit y probit
modelo_logit <- glm(AHD ~ Age + Sex + Chol + ExAng + Ca + Thal, data = heart_df, family = binomial(link = "logit"))
modelo_probit <- glm(AHD ~ Age + Sex + Chol + ExAng + Ca + Thal, data = heart_df, family = binomial(link = "probit"))

# Comparación visual
x_grid <- seq(min(heart_df$Age), max(heart_df$Age), length.out = 100)
pred_data <- data.frame(Age = x_grid, Sex = 1, Chol = mean(heart_df$Chol),
                        ExAng = 1, Ca = 2, Thal = factor("reversable", levels = c("fixed", "normal", "reversable")))

p_logit <- predict(modelo_logit, newdata = pred_data, type = "response")
p_probit <- predict(modelo_probit, newdata = pred_data, type = "response")

plot(x_grid, p_logit, type = "l", col = "blue", ylim = c(0,1), lwd = 2, main = "Logit vs Probit", ylab = "Probabilidad", xlab = "Edad")
lines(x_grid, p_probit, col = "red", lwd = 2, lty = 2)
legend("bottomright", legend = c("Logit", "Probit"), col = c("blue", "red"), lty = c(1,2), lwd = 2)
